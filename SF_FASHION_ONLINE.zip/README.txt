SF FASHION — ONLINE STORE

Included:
- Customer storefront
- Cash-on-Delivery checkout
- Online order storage in data/store.json
- Secure session-based admin login
- Admin product add/edit/delete
- Admin order viewing and status updates

RUN ON A COMPUTER:
1. Install Node.js 18+.
2. Open a terminal in this folder.
3. Run: npm install
4. Run: npm start
5. Open http://localhost:3000
6. Admin: http://localhost:3000/admin.html
7. Demo admin password: SF2026

FOR PUBLIC DEPLOYMENT:
Set an environment variable:
ADMIN_PASSWORD=YOUR_STRONG_PASSWORD

IMPORTANT:
This version is a complete starter full-stack store, but for serious production use you should move the JSON database to a hosted database, add image storage, backups, rate limiting, HTTPS, and a proper user/admin account system. COD orders are stored on the server; no payment gateway is included.
